//
//  CoreDataManager.swift
//  CinemaApp
//
//  Created by Rustem Orazbek on 21.05.2021.
//

import Foundation
import CoreData

class CoreDataManager {
    
    static let shared = CoreDataManager()
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "LocalDBModel")
        container.loadPersistentStores(completionHandler: {
            (storeDescription, error) in
            if let error = error as NSError?{
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    private init() {}
    
    func save() {
        let context = persistentContainer.viewContext
        
        do{
            try context.save()
        } catch{
            print(error)
        }
    }
    
    func allMovies() -> [MovieEntiy.Movie] {
        let context = persistentContainer.viewContext
        let request: NSFetchRequest<MoviesEntity> = MoviesEntity.fetchRequest()
        
        let movies = try? context.fetch(request)
        
        return movies?.map( { MovieEntiy.Movie(movie: $0) } ) ?? []
        
    }
    
    func addMovie(_ movie: MovieEntiy.Movie) {
        let context = persistentContainer.viewContext
        
        context.perform {
            let newMovie = MoviesEntity(context: context)
            newMovie.id = Int64(movie.id)
            newMovie.image = movie.poster
            newMovie.rating = movie.rating
            newMovie.release_date = movie.releaseDate
            newMovie.title = movie.title
        }
        save()
    }
    
    func addMovie(_ movie: MovieDetail) {
        let context = persistentContainer.viewContext
        
        if let id = movie.id {
            context.perform {
                let newMovie = MoviesEntity(context: context)
                newMovie.id = Int64(id)
                newMovie.image = movie.poster
                newMovie.rating = movie.rating ?? 0
                newMovie.release_date = movie.releaseDate
                newMovie.title = movie.title
        }
        }
        save()
    }
    
    func deleteMovie(with id: Int){
        let context = persistentContainer.viewContext
        
        if let movie = MoviesEntity.findMovie(with: id, context: context) {
            context.delete(movie)
        }
        save()
    }
    
    
}
