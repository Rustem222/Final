//
//  MovieCell.swift
//  CinemaApp
//
//  Created by Rustem Orazbek on 22.04.2021.
//

import UIKit
import Kingfisher

class MovieCell: UITableViewCell {
    
    public static let identtifier: String = "MovieCell"

    @IBOutlet private weak var containerRatingView: UIView!
    @IBOutlet private weak var ratingLabel: UILabel!
    @IBOutlet private weak var movieTitleLabel: UILabel!
    @IBOutlet private weak var movieDateLabel: UILabel!
    @IBOutlet private weak var posterImageView: UIImageView!
    
    @IBOutlet private weak var favoriteButton: UIButton!
    
    private let context = CoreDataManager.shared.persistentContainer.viewContext
    
    public var movie: MovieEntiy.Movie? {
        didSet {
            if let movie = movie{
                let posterURL = URL(string: "https://image.tmdb.org/t/p/w400" + (movie.poster ?? ""))
                posterImageView.kf.setImage(with: posterURL)
                ratingLabel.text = "\(String(describing: movie.rating))"
                movieTitleLabel.text = movie.title
                movieDateLabel.text = movie.releaseDate
                

                
                
                if let _ = MoviesEntity.findMovie(with: movie.id, context: context) {
                        favoriteButton.setImage(UIImage(named: "starFilled"), for: .normal)
                    CoreDataManager.shared.deleteMovie(with: movie.id)
                    } else {
                        
                        favoriteButton.setImage(UIImage(named: "star"), for: .normal)
                           // movie.id = movieId
                            //CoreDataManager.shared.addMoview(movie)
                        
                    
                }
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        selectionStyle = .none
        containerRatingView.layer.cornerRadius = 20
        containerRatingView.layer.masksToBounds = true
        posterImageView.layer.cornerRadius = 12
        posterImageView.layer.masksToBounds = true
    }
    @IBAction func favoriteButtonPressed(_ sender: Any) {
        let context = CoreDataManager.shared.persistentContainer.viewContext
        
        if let movie = movie {
            if let _ = MoviesEntity.findMovie(with: movie.id, context: context) {
                favoriteButton.setImage(UIImage(named: "star"), for: .normal)
                CoreDataManager.shared.deleteMovie(with: movie.id)
            } else {
                
                favoriteButton.setImage(UIImage(named: "starFilled"), for: .normal)
                   // movie.id = movieId
                    CoreDataManager.shared.addMovie(movie)
                
            }
        }
    }
    
}

