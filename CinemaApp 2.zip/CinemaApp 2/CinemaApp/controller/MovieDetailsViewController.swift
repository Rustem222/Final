//
//  MovieDetailsViewController.swift
//  CinemaApp
//
//  Created by Rustem Orazbek on 22.04.2021.
//

import UIKit
import Alamofire
import Kingfisher

class MovieDetailsViewController: UIViewController {

    public var movieId: Int?
    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var containerRatingView: UIView!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var movieTitleLabel: UILabel!
    @IBOutlet weak var movieDateLabel: UILabel!
    
    @IBOutlet weak var movieDescriptionLabel: UILabel!
    @IBOutlet weak var favoriteButton: UIButton!
    
    private var TRENDING_MOVIE_BY_ID = "https://api.themoviedb.org/3/movie/"
    private var movie: MovieDetail??
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        containerRatingView.layer.cornerRadius = 20
        containerRatingView.layer.masksToBounds = true

        TRENDING_MOVIE_BY_ID += "\(movieId!)" + "?api_key=fe42a322fd1e6c6e8c8112f0eaa22bea"
        getMovieDetailById()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let context = CoreDataManager.shared.persistentContainer.viewContext
        
        if let movieId = movieId {
            if let _ = MoviesEntity.findMovie(with: movieId, context: context) {
                favoriteButton.setImage(UIImage(named: "starFilled"), for: .normal)
            } else {
                favoriteButton.setImage(UIImage(named: "star"), for: .normal)
            }
        }
    }
    
    @IBAction func favoriteButtonPressed(_ sender: Any) {
        let context = CoreDataManager.shared.persistentContainer.viewContext
        
        if let movieId = movieId {
            if let _ = MoviesEntity.findMovie(with: movieId, context: context) {
                favoriteButton.setImage(UIImage(named: "star"), for: .normal)
                CoreDataManager.shared.deleteMovie(with: movieId)
            } else {
                if let movie = movie {
                favoriteButton.setImage(UIImage(named: "starFilled"), for: .normal)
                   // movie.id = movieId
                    CoreDataManager.shared.addMovie(movie!)
                }
            }
        }

    }
}
extension MovieDetailsViewController {
    func getMovieDetailById() {
        AF.request(TRENDING_MOVIE_BY_ID, method: .get, parameters: [:]).responseJSON { (response) in
            switch response.result {
            case .success:
                if let data = response.data {
                    do {
                    let movieJSON = try JSONDecoder().decode(MovieDetail.self, from: data)
                        self.title = movieJSON.title
                        self.ratingLabel.text = "\(movieJSON.rating)"
                        self.movieTitleLabel.text = movieJSON.title
                        self.movieDescriptionLabel.text = movieJSON.overview
                        self.movieDateLabel.text = movieJSON.releaseDate
                        let posterURL = URL(string: "https://image.tmdb.org/t/p/w500" + (movieJSON.poster ?? ""))
                        self.posterImageView.kf.setImage(with: posterURL)
                    }
                    catch let errorJSON {
                        print(errorJSON)
                    }
                }
                break
            case .failure:
                print("failed to retrieve JSON")
            }
        }
    }
}
