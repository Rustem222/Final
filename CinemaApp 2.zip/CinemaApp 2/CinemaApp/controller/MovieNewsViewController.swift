//
//  ViewController.swift
//  CinemaApp
//
//  Created by Rustem Orazbek on 22.04.2021.
//

import UIKit
import Alamofire

class MovieNewsViewController: UIViewController {
    
    private let TrendingMoviesURL: String = "https://api.themoviedb.org/3/trending/movie/week?api_key=fe42a322fd1e6c6e8c8112f0eaa22bea"

    @IBOutlet weak var tableView: UITableView!
    
    private var movies: [MovieEntiy.Movie] = [MovieEntiy.Movie]() {
        didSet {
            tableView.reloadData()
        }
    }
    
    private var pageNumber: Int = 1
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
   //     tableView.contentOffset = UIEdgeInsets(top: 16, left: 0, bottom: 0, right: 0)
        tableView.register(UINib(nibName: MovieCell.identtifier, bundle: Bundle(for: MovieCell.self)), forCellReuseIdentifier: MovieCell.identtifier)
        
        
        getTrendingMovies()
    }
}

extension MovieNewsViewController {
    
    private func getTrendingMovies(_ page: Int? = nil) {
        var params: [String: Any] = [:]
        
        if let page = page {
            params["page"] = page
        }
        
        AF.request(TrendingMoviesURL, method: .get, parameters: [:]).responseJSON { (response) in
            switch response.result{
            case .success:
                if let data = response.data {
                    do {
                        let movieJSON = try JSONDecoder().decode(MovieEntiy.self, from: data)
                        self.movies += movieJSON.movies
      //                  print(movieJSON)
                    } catch let errorJSON {
                        print(errorJSON)
                    }
                }
            case .failure:
                print("TrendingMoviesURL failed to retrieve JSON")
            }
        }
    }
}

extension MovieNewsViewController: UITableViewDelegate {
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        if let vc = storyboard.instantiateViewController(withIdentifier: "MovieDetailsViewController") as? MovieDetailsViewController {
            vc.modalPresentationStyle = .fullScreen
            vc.movieId = movies[indexPath.row].id
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        let deltaOffset = maximumOffset - currentOffset
        
        if deltaOffset <= 10 && currentOffset < 200 {
            pageNumber += 1
            getTrendingMovies(pageNumber)
        }
    }
}

extension MovieNewsViewController: UITableViewDataSource {
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MovieCell.identtifier, for: indexPath)
            as! MovieCell
        cell.movie = movies[indexPath.row]
        return cell
    }
    
    
}
