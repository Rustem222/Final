//
//  FavoriteMoviesViewController.swift
//  CinemaApp
//
//  Created by Rustem Orazbek on 21.05.2021.
//

import UIKit

class FavoriteMoviesViewController: UIViewController {
    
    private var movies: [MovieEntiy.Movie] = [] {
        didSet {
            
                tableView.reloadData()
            
        }
    }

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: MovieCell.identtifier, bundle: nil), forCellReuseIdentifier: MovieCell.identtifier)
        tableView.separatorStyle = .none
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        movies = CoreDataManager.shared.allMovies()
    }
    
}

extension FavoriteMoviesViewController: UITableViewDelegate {
   
    
}

extension FavoriteMoviesViewController: UITableViewDataSource {
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MovieCell.identtifier, for: indexPath)
            as! MovieCell
        cell.movie = movies[indexPath.row]
        return cell
    }
    
    
}

